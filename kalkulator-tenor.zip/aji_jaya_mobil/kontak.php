<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Bootstrap -->
     <link href="css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome-->
    <link href="fontawesome/css/all.min.css" rel="stylesheet" />
    <title>kontak</title>
</head>
<body>
<nav class="navbar navbar-light bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand font-monospace text-light" href="index.php">
      <img src="img/logo-mobil.png" alt="" width="70" height="70" class="">
      AJI JAYA MOBIL
    </a>
    <li class="nav-item dropdown d-flex">
          <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Option
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="index.php">Beranda</a></li>
            <li><a class="dropdown-item" href="biografi.php">Biografi</a></li>
            <li><a class="dropdown-item" href="kontak.php">Kontak</a></li>
          </ul>
    </li>
  </div>
</nav>
<article class="container text-center font-monospace">
<div class="row g-0 bg-body-secondary position-relative bg-secondary">
  <div class="col-md-6 mb-md-0 p-md-4">
  <label for="exampleDataList" class="form-label">email</label>
<input class="form-control" list="datalistOptions" id="exampleDataList" placeholder="isi disini...">
<label for="exampleDataList" class="form-label">No.Hanpone/WA</label>
<input class="form-control" list="datalistOptions" id="exampleDataList" placeholder="isi disini...">
<label for="exampleDataList" class="form-label">Nama</label>
<input class="form-control" list="datalistOptions" id="exampleDataList" placeholder="isi disini...">
<label for="exampleDataList" class="form-label">Perihal</label>
<div class="form-floating">
  <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
  <label for="floatingTextarea2">Comments</label>
</div>
<h1></h1>
    <button type="button" class="btn btn-primary">Kirim</button>
  </div>
  <div class="col-md-6 p-4 ps-md-0">
    <h5 class="mt-0">AJI JAYA MOBIL</h5>
    <img src="img/logo-mobil.png" alt="">
  </div>
</div>
</article>
<footer class="bg-dark pt-5 pb-4 text-light">
    <div class="container">
    <h6>ig : @Diksatraa</h6>
    <h6>wa : +628199918819</h6>
    <h7>linkedin : Diksatra Aji Samboga</h7>
    </div>
</footer>
</body>
</html>