<?php
// Mulai session untuk melacak status tombol
session_start();

// Cek apakah tombol sudah ditekan
if (isset($_POST['submit'])) {
    // Set session untuk menandai bahwa tombol sudah ditekan
    $_SESSION['button_clicked'] = true;
    echo "Tombol telah ditekan!";
}

// Periksa status tombol yang sudah ditekan
$button_disabled = isset($_SESSION['button_clicked']) && $_SESSION['button_clicked'] == true;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Button Hanya Sekali Klik</title>
</head>
<body>

<h2>Form Tombol Satu Kali Klik</h2>

<!-- Form untuk menekan tombol -->
<form method="POST">
    <!-- Tombol hanya bisa ditekan sekali -->
    <button type="submit" name="submit" <?php echo $button_disabled ? 'disabled' : ''; ?>>
        Klik Saya
    </button>
</form>

</body>
</html>
