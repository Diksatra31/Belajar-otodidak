<?php
$harmob = @$_POST['tharmob'];
$dp = @$_POST ['tdp'];
$tenor = @$_POST ['ttenor'];
$hasil = @$_POST ['thasil'];
$tbulan = @$_POST ['ttbulan'];

if(isset($_POST['hitung']))
{
    $hasil = ((int)$harmob+floatval(20/100)-($dp/100))/($tenor*12);
    $tbulan = $tenor*12;
    $harmob = number_format(floatval($harmob), 0, ',', '.');
    $hasil = number_format(floatval($hasil), 0, ',', '.');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome-->
    <link href="fontawesome/css/all.min.css" rel="stylesheet" />

    <title>Beranda</title>
</head>
<body>
<!--Tampilan Navbar-->
<nav class="navbar navbar-light bg-dark">
  <div class="container">
    <a class="navbar-brand font-monospace text-light" href="#">
      <img src="img/logo-mobil.png" alt="" width="70" height="70" class="">
      AJI JAYA MOBIL
    </a>
    <li class="nav-item dropdown d-flex">
          <a class="nav-link dropdown-toggle text-light font-monospace" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Option
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Beranda</a></li>
            <li><a class="dropdown-item" href="biografi.php">Tentang Perusahaan</a></li>
            <li><a class="dropdown-item" href="kontak.php">Kontak</a></li>
          </ul>
    </li>
  </div>
</nav>
<!--image slider-->

<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/dealer.png" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="img/dealer1.png" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="img/dealer2.png" class="d-block w-100" alt="">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
  </button>
</div>
<!--Perhitungan-->
<tr>
    <td colspan="3"> <hr> </td>
</tr>
<form action="" method="post" >
    <h1 class="text-center font-monospace sm-3">Perhitungan Kredit Mobil</h1>
    <table align="center" >
    <tr class="font-monospace">
    <td>Harga Mobil</td>
    <td>: Rp.</td>
    <td>
        <input type="text" name="tharmob" id="tharmob" value="<?=$harmob?>">
    </td>
    </tr>
    <tr class="font-monospace">
    <td>DP</td>
    <td>:</td>
    <td>
        <input type="text" name="tdp" value="<?=$dp?>"> %
    </td>
    </tr>
    <tr class="font-monospace">
    <td>Tenor</td>
    <td>:</td>
    <td>
        <input type="text" name="ttenor" value="<?=$tenor?>">Tahun <input type="text" name="ttbulan" value="<?=$tbulan?>">Bulan
    </td>
    </tr>
    <tr class="font-monospace">
    <td>Bunga</td>
    <td>:</td>
    <td>
        20%(Dari Harga Mobil)
    </td>
    </tr>
    <tr class="font-monospace">
    <td>
        <button name="hitung" type="submit">Hitung</button>
    </td>
    </tr>
     <tr>
     <td colspan="3"> <hr> </td>
     </tr>
    <tr class="font-monospace">
    <td>Hasil</td>
    <td>: Rp.</td>
    <td>
        <input type="text" name="thasil" value="<?=$hasil?>"> / Bulan
    </td>
    </tr>
    </table>
</form>
<tr>
    <td colspan="3"> <hr> </td>
</tr>
<!--Footer-->
<footer class="bg-dark pt-5 pb-4 text-light">
    <div class="container">
    <h6>ig : @Diksatraa</h6>
    <h6>wa : +628199918819</h6>
    <h7>linkedin : Diksatra Aji Samboga</h7>
    </div>
</footer>
</body>
</html>