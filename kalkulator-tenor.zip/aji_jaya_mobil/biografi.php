<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome-->
    <link href="fontawesome/css/all.min.css" rel="stylesheet" />

    <title>Beranda</title>
</head>
<body>
<nav class="navbar navbar-light bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand font-monospace text-light" href="index.php">
      <img src="img/logo-mobil.png" alt="" width="70" height="70" class="">
      AJI JAYA MOBIL
    </a>
    <li class="nav-item dropdown d-flex">
          <a class="nav-link dropdown-toggle text-light font-monospace" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Option
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="index.php">Beranda</a></li>
            <li><a class="dropdown-item" href="biografi.php">Biografi</a></li>
            <li><a class="dropdown-item" href="kontak.php">Kontak</a></li>
          </ul>
    </li>
  </div>
</nav>
<article class="container text-center">
<div class="row g-0 bg-body-secondary position-relative bg-secondary">
  <div class="col-md-6 mb-md-0 p-md-4">
    <img src="img/logo-mobil.png" class="w-100" alt="...">
  </div>
  <div class="col-md-6 p-4 ps-md-0 font-monospace">
    <h5 class="mt-0">AJI JAYA MOBIL</h5>
    <p>Aji Jaya Mobil Adalah perusahaan yang Bergerak Dibidang Penjualan Mobil Sport(Hypercar,Supercar dan Sportcar). Perusahaan ini Telah Berdiri Semenjak Tahun 1944 atau 1 tahun Sebelum Merdeka dan 1 Tahun sebelum Amerika Menjatuhkan Bom di Hiroshima Nagasaki. Pendiri perusahaan ini Bernama Diksatra Aji Samboga dan Nama Aji Jaya Mobil itu Diambil dari Nama si Pendiri Perusahaan tersebut. Perusahaan ini Berdiri Dengan Tujuan Menyelesaikan Tugas Untuk Sertifikasi Junior Web Developer. Sejak tahun 1985 hingga 2019 kami telah memproduksi 232 unit mobil di mana 86 unit diantaranya merupakan Hypercar. Hingga saat ini kami telah mengekspor 45 unit mobil baik Sportcar sampai Hypercar. Sejak tahun 1988 hingga tahun 2019 kami telah memproduksi total 282 produk energi dan elektrifikasi seperti Paghani, Lamborghini, dan lainnya. Upaya Aji Jaya Mobil ini merupakan langkah besar untuk memasuki industri global.</p> 
  </div>
</div>
</article>
<footer class="bg-dark pt-5 pb-4 text-light">
    <div class="container">
    <h6>ig : @Diksatraa</h6>
    <h6>wa : +628199918819</h6>
    <h7>linkedin : Diksatra Aji Samboga</h7>
    </div>
</footer>
</body>
</html>