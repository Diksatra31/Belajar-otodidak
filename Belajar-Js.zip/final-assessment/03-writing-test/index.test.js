import { test } from 'node:test';
import assert from 'node:assert';
import { sum } from './index.js'; // Mengimpor fungsi sum

// Pengujian pertama: Penjumlahan dua bilangan positif
test('sum of 2 and 3 should be 5', () => {
  const result = sum(2, 3);
  assert.strictEqual(result, 5, 'Expected sum(2, 3) to be 5');
});

// Pengujian kedua: Penjumlahan dua bilangan negatif
test('sum of -2 and -3 should be -5', () => {
  const result = sum(-2, -3);
  assert.strictEqual(result, -5, 'Expected sum(-2, -3) to be -5');
});

// Pengujian ketiga: Penjumlahan bilangan positif dan negatif
test('sum of 7 and -3 should be 4', () => {
  const result = sum(7, -3);
  assert.strictEqual(result, 4, 'Expected sum(7, -3) to be 4');
});

// Pengujian keempat: Penjumlahan dengan nol
test('sum of 0 and 5 should be 5', () => {
  const result = sum(0, 5);
  assert.strictEqual(result, 5, 'Expected sum(0, 5) to be 5');
});
