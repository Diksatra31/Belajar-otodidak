import sum from './sum.js';
import assert from 'node:assert';
import { test } from 'node:test';

// Menguji fungsi sum
test('Sum of two positive numbers', () => {
  const result = sum(3, 5);
  assert.strictEqual(result, 8, 'Expected sum of 3 and 5 to be 8');
});

test('Sum of a positive number and zero', () => {
  const result = sum(10, 0);
  assert.strictEqual(result, 10, 'Expected sum of 10 and 0 to be 10');
});

test('Sum of two negative numbers should return 0', () => {
  const result = sum(-3, -5);
  assert.strictEqual(result, 0, 'Expected sum of -3 and -5 to be 0');
});

test('Sum of a positive number and a negative number should return 0', () => {
  const result = sum(3, -5);
  assert.strictEqual(result, 0, 'Expected sum of 3 and -5 to be 0');
});

test('Sum when one or both inputs are not numbers should return 0', () => {
  const result1 = sum(3, '5');
  const result2 = sum('3', 5);
  const result3 = sum('a', 'b');
  
  assert.strictEqual(result1, 0, 'Expected sum of 3 and "5" to be 0');
  assert.strictEqual(result2, 0, 'Expected sum of "3" and 5 to be 0');
  assert.strictEqual(result3, 0, 'Expected sum of "a" and "b" to be 0');
});
