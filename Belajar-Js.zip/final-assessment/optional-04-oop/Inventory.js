/**
 * TODO
 * Selesaikan kode pembuatan class Inventory dengan ketentuan:
 * - Memiliki properti `items` untuk menampung daftar item dalam bentuk array.
 * - Memiliki method `addItem` untuk menambahkan item ke properti `items`.
 * - Memiliki method `removeItem` untuk menghapus item berdasarkan `id`.
 * - Memiliki method `listItems` untuk mengembalikan string yang merupakan informasi detail barang (dipanggil dari fungs `item.displayDetails()`).
 */

class Inventory {
    constructor() {
      this.items = []; // Properti untuk menampung daftar item
    }
  
    /**
     * Menambahkan item ke dalam daftar items.
     * @param {Object} item - Objek item yang memiliki metode displayDetails.
     */
    addItem(item) {
      this.items.push(item);
    }
  
    /**
     * Menghapus item dari daftar items berdasarkan id.
     * @param {string} id - ID dari item yang ingin dihapus.
     */
    removeItem(id) {
      this.items = this.items.filter((item) => item.id !== id);
    }
  
    /**
     * Mengembalikan string berupa informasi detail dari semua item.
     * @returns {string} - Informasi detail dari semua item.
     */
    listItems() {
      return this.items.map((item) => item.displayDetails()).join('\n');
    }
  }
  
  // Jangan hapus kode di bawah ini!
  export default Inventory;
  