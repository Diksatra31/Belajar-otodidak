/**
 * TODO
 * Selesaikan kode pembuatan class Item dengan ketentuan:
 * - Memiliki properti `id` (number), `name` (string), `quantity` (number), dan `price` (number).
 * - Memiliki method `updateDetails()` untuk mengubah nilai `name`, `quantity`, dan `price`.
 * - Memiliki method `displayDetails()` yang mengembalikan informasi detail dari Item dengan format:
 *   ```
 *     ID: ${id}, Name: ${name}, Quantity: ${quantity}, Price: ${price}
 *   ```
 */

class Item {
    constructor(id, name, quantity, price) {
      this.id = id; // Properti ID
      this.name = name; // Properti Nama
      this.quantity = quantity; // Properti Kuantitas
      this.price = price; // Properti Harga
    }
  
    /**
     * Mengubah nilai properti name, quantity, dan price.
     * @param {string} name - Nama baru item.
     * @param {number} quantity - Kuantitas baru item.
     * @param {number} price - Harga baru item.
     */
    updateDetails(name, quantity, price) {
      this.name = name;
      this.quantity = quantity;
      this.price = price;
    }
  
    /**
     * Menampilkan detail item dalam format string.
     * @returns {string} - Detail item.
     */
    displayDetails() {
      return `ID: ${this.id}, Name: ${this.name}, Quantity: ${this.quantity}, Price: ${this.price}`;
    }
  }
  
  // Jangan hapus kode di bawah ini!
  export default Item;
  